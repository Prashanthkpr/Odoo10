# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from datetime import datetime,date,timedelta
from string import Template

from odoo.exceptions import UserError

class hr_birthdays(models.Model):
	
    _inherit='hr.employee'

    age=fields.Char(string='Age',compute='_compute_age')
    contract=fields.Many2one('hr.contract')
    total_allocation=fields.Float(compute='_get_total_allocation',string="Total Allocation")
    max_leaves = fields.Float(compute='_compute_leaves', string='Maximum Allowed',
        help='This value is given by the sum of all holidays requests with a positive value.')
    leaves_taken = fields.Float(compute='_compute_leaves', string='Leaves Already Taken',
        help='This value is given by the sum of all holidays requests with a negative value.')
    
    virtual_remaining_leaves = fields.Float(compute='_compute_leaves', string='Virtual Remaining Leaves',
        help='Maximum Leaves Allowed - Leaves Already Taken - Leaves Waiting Approval')
    leave_type=fields.Char(string="Leave Type",compute='_get_leave_type')
        
    @api.one
    @api.depends('birthday')
    def _compute_age(self):
        if self.birthday:

            d1 = datetime.strptime(self.birthday, "%Y-%m-%d")
            age_calc = (datetime.today() - d1).days/365
            age= str(age_calc) + ' Years'
            self.age = age

    
    @api.one
    def _get_total_allocation(self):
        emp=self.env['hr.holidays'].search([('employee_id','=',self.id)])
        for count in emp:
            self.total_allocation=+count.number_of_days_temp
            print self.total_allocation ,count.employee_id

    @api.multi
    def get_days(self, employee_id):
        # need to use `dict` constructor to create a dict per id
        result = dict((id, dict(max_leaves=0, leaves_taken=0, remaining_leaves=0, virtual_remaining_leaves=0)) for id in self.ids)

        holidays = self.env['hr.holidays'].search([
            ('employee_id', '=', employee_id),
            ('state', 'in', ['confirm', 'validate1', 'validate']),
            ('holiday_status_id', 'in', self.ids)
        ])

        for holiday in holidays:
            status_dict = result[holiday.holiday_status_id.id]
            if holiday.type == 'add':
                if holiday.state == 'validate':
                    # note: add only validated allocation even for the virtual
                    # count; otherwise pending then refused allocation allow
                    # the employee to create more leaves than possible
                    status_dict['virtual_remaining_leaves'] += holiday.number_of_days_temp
                    status_dict['max_leaves'] += holiday.number_of_days_temp
                    status_dict['remaining_leaves'] += holiday.number_of_days_temp
            elif holiday.type == 'remove':  # number of days is negative
                status_dict['virtual_remaining_leaves'] -= holiday.number_of_days_temp
                if holiday.state == 'validate':
                    status_dict['leaves_taken'] += holiday.number_of_days_temp
                    status_dict['remaining_leaves'] -= holiday.number_of_days_temp
        return result
        

    @api.multi
    def _compute_leaves(self):

        print "***********************"
        data_days = {}
        if 'employee_id' in self._context:
            employee_id = self._context['employee_id']
        else:
            employee_id = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1).id

        if employee_id:
            data_days = self.get_days(employee_id)

        for holiday_status in self:
            result = data_days.get(holiday_status.id, {})
            holiday_status.max_leaves = result.get('max_leaves', 0)
            holiday_status.leaves_taken = result.get('leaves_taken', 0)
            
            holiday_status.virtual_remaining_leaves = result.get('virtual_remaining_leaves', 0) 

    @api.one
    def _get_leave_type(self):
        
        types=[]
        obj=self.env['hr.holidays.status'].search([])
        for rec in obj:
            print rec.write_date ,self.write_date,"***************"
            if rec.write_date==self.write_date:
                print rec.write_date ,self.write_date,"***************"
                self.leave_type=rec.name



class Dashboard(models.Model):
    
    _name='hr.dashboard'

    name = fields.Char(string="Name")
    color = fields.Integer(string='Color Index')
    today_birthday_count=fields.Integer(compute='_get_count')
    upcoming_birthday_count=fields.Integer(compute='_get_count')
    today_anniversary_count=fields.Integer(compute='_get_count')
    today_leaves_count=fields.Integer(compute='_get_count')
    total_employees=fields.Integer(compute='_get_count')
    upcoming_holidays_count=fields.Integer(compute='_get_count')
    
    @api.model
    def _get_count(self):
         
         self.today_birthday_count=self.env['hr.employee'].search_count([('birthday','like',date.today().strftime("%____%-%m-%d"))])
         self.upcoming_birthday_count=self.env['hr.employee'].search_count(['|','|',('birthday','like',((date.today()+timedelta(days=3)).strftime("%____%-%m-%d"))),('birthday','like',((date.today()+ timedelta(days=2)).strftime("%____%-%m-%d"))),('birthday','like',((date.today()+timedelta(days=1)).strftime("%____%-%m-%d")))])
         self.today_anniversary_count=self.env['hr.contract'].search_count([('date_start','like',date.today().strftime("%____%-%m-%d"))])
         self.today_leaves_count=self.env['hr.holidays'].search_count([('state','in',['validate']),('date_from','<=',date.today().strftime("%Y-%m-%d")),('date_to','>=',date.today().strftime("%Y-%m-%d"))])
         self.total_employees=self.env['hr.employee'].search_count([])
         self.upcoming_holidays_count=self.env['hr.holidays.public.line'].search_count([('date','<=',((date.today() + timedelta(days=5)).strftime("%Y-%m-%d")))])   

    

    

    @api.multi
    def send_followup_mail(self):
    # write your logic to find the time intervals(day 1, day 2, week)
    # based on the time interval trigger the mails.
    # use a loop to get the mail template id from the one2many

        template = self.env['ir.model.data'].get_object('hr_birthdays', 'birthday_email_templates')
        
        rec=self.env['hr.employee'].search([('birthday','like',date.today().strftime("%____%-%m-%d"))])
        data=[]
        data=rec.read(['work_email','name'])
        company_name=self.env.user.company_id.name
        admin_name=self.env.user.name
        
        for i in range(len(data)):
            template.write({'email_to':data[i]['work_email']})
            name=data[i]['name']
            body='''\
                        <html>
                          <head></head>
                          <body>
                            <p>Dear {name},<br/><br/>
                            Everyone here at work speaks well of you thanks to your positive attitude towards work. <br/> I really admire that a lot. 
                            Keep up the good work.<br/> Happy birthday<br/></p>
                            Regards,<br/>
                      {company_name},<br/>
                      {admin_name}
                          </body>
                        </html>
                        '''.format(name=name,company_name=company_name,admin_name=admin_name)
            template.write({'body_html':body}) 
            #this will trigger the mail
            if template:
               
               template.send_mail(self.id, force_send=True, raise_exception=True)


    @api.multi
    def birthday_report(self,context=None):

        rec = self.env['hr.employee'].search([('birthday','like',date.today().strftime("%____%-%m-%d"))])
        
        data = {}
        data['form'] = rec.read(['name', 'birthday', 'work_email','mobile_phone','age'])
        
        active_ids = self.env.context.get('active_ids', [])
        datas = {
             'ids': active_ids,
             'model': 'hr.dashboard',
             'form': data
             }
        return self.env['report'].get_action(rec, 'hr_birthdays.report_birthdays',data=datas)

    @api.multi
    def upcomingbirthday_report(self,context=None):

        rec = self.env['hr.employee'].search(['|','|',('birthday','like',((date.today()+timedelta(days=3)).strftime("%____%-%m-%d"))),('birthday','like',((date.today()+ timedelta(days=2)).strftime("%____%-%m-%d"))),('birthday','like',((date.today()+timedelta(days=1)).strftime("%____%-%m-%d")))])
        
        data = {}
        data['form'] = rec.read(['name', 'birthday', 'work_email','mobile_phone','age'])
        

        active_ids = self.env.context.get('active_ids', [])
        datas = {
             'ids': active_ids,
             'model': 'hr.dashboard',
             'form': data
             }
        return self.env['report'].get_action(rec, 'hr_birthdays.report_upcomingbirthdays',data=datas) 

    @api.multi
    def anniversary_report(self,context=None):

        rec = self.env['hr.contract'].search([('date_start','like',date.today().strftime("%____%-%m-%d"))])
        
        data = {}
        data['form'] = rec.read(['employee_id', 'date_start', 'experience'])
        

        active_ids = self.env.context.get('active_ids', [])
        datas = {
             'ids': active_ids,
             'model': 'hr.dashboard',
             'form': data
             }
        return self.env['report'].get_action(rec,'hr_birthdays.report_anniversary',data=datas)

    @api.multi
    def todayleaves_report(self,context=None):

        
        rec = self.env['hr.holidays'].search([('state','in',['validate']),('date_from','<=',date.today().strftime("%Y-%m-%d")),('date_to','>=',date.today().strftime("%Y-%m-%d"))])
        
        data = {}
        data['form'] = rec.read(['employee_id', 'holiday_status_id', 'date_to'])
        

        active_ids = self.env.context.get('active_ids', [])
        datas = {
             'ids': active_ids,
             'model': 'hr.dashboard',
             'form': data
             }
        return self.env['report'].get_action(rec,'hr_birthdays.report_leaves',data=datas)                            
         


class TodayBirthdayReport(models.AbstractModel):
    _name = 'report.hr_birthdays.report_birthdays'

    
    @api.model
    def render_html(self, docids, data=None):
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        register_ids = self.env.context.get('active_ids', [])
        contrib_registers = self.env['hr.employee'].browse(register_ids)
        docs = self.env['hr.employee'].browse(self.env.context.get('active_id'))
        rec = self.env['hr.employee'].search([('birthday','like',date.today().strftime("%____%-%m-%d"))])
        
        data1 = {}
        data1['form'] = rec.read(['name', 'birthday', 'work_email','mobile_phone','age'])
       
        
        lines_data = data1['form']
        
        docargs = {
            'doc_ids': register_ids,
            'doc_model': 'hr.dashboard',
            'docs': contrib_registers,
            'data': data,
            'lines_data': lines_data,
            
        }
        return self.env['report'].render('hr_birthdays.report_birthdays', docargs)            

class UpcomingBirthdayReport(models.AbstractModel):
    _name = 'report.hr_birthdays.report_upcomingbirthdays'

    
    @api.model
    def render_html(self, docids, data=None):
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        register_ids = self.env.context.get('active_ids', [])
        contrib_registers = self.env['hr.employee'].browse(register_ids)
        docs = self.env['hr.employee'].browse(self.env.context.get('active_id'))
        rec = self.env['hr.employee'].search(['|','|',('birthday','like',((date.today()+timedelta(days=3)).strftime("%____%-%m-%d"))),('birthday','like',((date.today()+ timedelta(days=2)).strftime("%____%-%m-%d"))),('birthday','like',((date.today()+timedelta(days=1)).strftime("%____%-%m-%d")))])
        
        data1 = {}
        data1['form'] = rec.read(['name', 'birthday', 'work_email','mobile_phone','age'])
        
        
        lines_data = data1['form']
        
        docargs = {
            'doc_ids': register_ids,
            'doc_model': 'hr.dashboard',
            'docs': contrib_registers,
            'data': data,
            'lines_data': lines_data,
            
        }
        return self.env['report'].render('hr_birthdays.report_upcomingbirthdays', docargs)

class AnniversaryReport(models.AbstractModel):
    _name = 'report.hr_birthdays.report_anniversary'

    
    @api.model
    def render_html(self, docids, data=None):
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        register_ids = self.env.context.get('active_ids', [])
        contrib_registers = self.env['hr.employee'].browse(register_ids)
        docs = self.env['hr.employee'].browse(self.env.context.get('active_id'))
        rec=self.env['hr.contract'].search([('date_start','like',date.today().strftime("%____%-%m-%d"))])
        data1 = {}
        data1['form'] = rec.read(['employee_id', 'date_start', 'experience'])
        print data1['form']
        
        lines_data = data1['form']
        
        docargs = {
            'doc_ids': register_ids,
            'doc_model': 'hr.dashboard',
            'docs': contrib_registers,
            'data': data,
            'lines_data': lines_data,
            
        }
        return self.env['report'].render('hr_birthdays.report_anniversary', docargs)

class TodayLeavesReport(models.AbstractModel):
    _name = 'report.hr_birthdays.report_leaves'

    
    @api.model
    def render_html(self, docids, data=None):
        if not data.get('form'):
            raise UserError(_("Form content is missing, this report cannot be printed."))

        register_ids = self.env.context.get('active_ids', [])
        contrib_registers = self.env['hr.employee'].browse(register_ids)
        docs = self.env['hr.employee'].browse(self.env.context.get('active_id'))
        rec = self.env['hr.holidays'].search([('state','in',['validate']),('date_from','<=',date.today().strftime("%Y-%m-%d")),('date_to','>=',date.today().strftime("%Y-%m-%d"))])
        data1 = {}
        data1['form'] = rec.read(['employee_id', 'holiday_status_id', 'date_to'])
        
        
        lines_data = data1['form']
        
        docargs = {
            'doc_ids': register_ids,
            'doc_model': 'hr.dashboard',
            'docs': contrib_registers,
            'data': data,
            'lines_data': lines_data,
            
        }
        return self.env['report'].render('hr_birthdays.report_leaves', docargs)

class Anniversary(models.Model):
    
    _inherit='hr.contract'

    experience=fields.Char(string='Experience',compute='_compute_years')


    @api.one
    @api.depends('date_start')
    def _compute_years(self):
        if self.date_start:

            d1 = datetime.strptime(self.date_start, "%Y-%m-%d")
            age_calc = (datetime.today() - d1).days/365
            experience= str(age_calc) + ' Years'
            self.experience = experience

class TodayLeaves(models.Model):

    _inherit='hr.holidays'

    max_leaves = fields.Float(compute='_compute_leaves', string='Maximum Allowed',
        help='This value is given by the sum of all holidays requests with a positive value.')
    leaves_taken = fields.Float(compute='_compute_leaves', string='Leaves Already Taken',
        help='This value is given by the sum of all holidays requests with a negative value.')
    remaining_leaves = fields.Float(compute='_compute_leaves', string='Remaining Leaves',
        help='Maximum Leaves Allowed - Leaves Already Taken')
    virtual_remaining_leaves = fields.Float(compute='_compute_leaves', string='Virtual Remaining Leaves',
        help='Maximum Leaves Allowed - Leaves Already Taken - Leaves Waiting Approval')

    double_validation = fields.Boolean(string='Apply Double Validation',
        help="When selected, the Allocation/Leave Requests for this type require a second validation to be approved.")

    @api.multi
    def get_days(self, employee_id):
        # need to use `dict` constructor to create a dict per id
        result = dict((id, dict(max_leaves=0, leaves_taken=0, remaining_leaves=0, virtual_remaining_leaves=0)) for id in self.ids)

        holidays = self.env['hr.holidays'].search([
            ('employee_id', '=', employee_id),
            ('state', 'in', ['confirm', 'validate1', 'validate']),
            ('holiday_status_id', 'in', self.ids)
        ])

        for holiday in holidays:
            status_dict = result[holiday.holiday_status_id.id]
            if holiday.type == 'add':
                if holiday.state == 'validate':
                    # note: add only validated allocation even for the virtual
                    # count; otherwise pending then refused allocation allow
                    # the employee to create more leaves than possible
                    status_dict['virtual_remaining_leaves'] += holiday.number_of_days_temp
                    status_dict['max_leaves'] += holiday.number_of_days_temp
                    status_dict['remaining_leaves'] += holiday.number_of_days_temp
            elif holiday.type == 'remove':  # number of days is negative
                status_dict['virtual_remaining_leaves'] -= holiday.number_of_days_temp
                if holiday.state == 'validate':
                    status_dict['leaves_taken'] += holiday.number_of_days_temp
                    status_dict['remaining_leaves'] -= holiday.number_of_days_temp
        return result
        

    @api.multi
    def _compute_leaves(self):

        print "***********************"
        data_days = {}
        if 'employee_id' in self._context:
            employee_id = self._context['employee_id']
        else:
            employee_id = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1).id

        if employee_id:
            data_days = self.get_days(employee_id)

        for holiday_status in self:
            result = data_days.get(holiday_status.id, {})
            holiday_status.max_leaves = result.get('max_leaves', 0)
            holiday_status.leaves_taken = result.get('leaves_taken', 0)
            
            holiday_status.virtual_remaining_leaves = result.get('virtual_remaining_leaves', 0) 


class LeavesSummery(models.Model):

    _inherit='hr.holidays.status'
                              
    emp_name=fields.Many2one('hr.employee',string="Employee Name")

    @api.model
    def _get_name(self):
        
        obj=self.env['hr.employee'].search([])
        for rec in obj:
            self.emp_name=rec.name
            

class PublicHolidays(models.Model):
    _inherit='hr.holidays.public.line'
      
    country_name=fields.Char(string="Country",compute='_get_country_name')

    @api.one
    def _get_country_name(self):
        obj=self.env["hr.holidays.public"].search([])
        for name in obj:
            if name.write_date==self.write_date:
                self.country_name=name.country_id.name
                
           