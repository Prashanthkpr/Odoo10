# -*- coding: utf-8 -*-
{
    'name': "Employee Dashboard",
    'category': 'Human Resources',
    'summary': """
        Employee Dashboard""",

    'description': """
        This application manage the Employee birthday deatils and showing the today employee birthdays.""",

    'author': "Enthsquare",
    'website': "http://www.enthsquare.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Employee',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['hr','hr_contract','hr_holidays','hr_public_holidays','mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        
        'views/templates.xml',
        'views/hr_birthdays_report.xml',
        'views/hr_birthdays_templates.xml',
        # 'views/hr_birthdays_button.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'qweb': [
        "static/src/xml/hr_dashboard.xml"
        ],
    'installable': True,
    'application': True,
    'auto_install': False,
}