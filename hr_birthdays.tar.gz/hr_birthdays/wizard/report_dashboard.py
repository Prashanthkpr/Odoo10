
from datetime import datetime
from dateutil import relativedelta

from odoo import api, fields, models


class PayslipLinesContributionRegister(models.TransientModel):
    _name = 'hr.dashboard'

    @api.multi
    def birthday_report(self,context=None):

            rec = self.env['hr.employee'].search([('birthday','like',date.today().strftime("%____%-%m-%d"))])
            
            data = {}
            data['form'] = rec.read(['name', 'birthday', 'work_email','mobile_phone','age'])
            print data['form'],"*************************"

            active_ids = self.env.context.get('active_ids', [])
            datas = {
                 'ids': active_ids,
                 'model': 'hr.employee',
                 'data': data['form']
                 }
            return self.env['report'].get_action(rec, 'hr_birthdays.report_contributionregister_birthdays',data=datas)