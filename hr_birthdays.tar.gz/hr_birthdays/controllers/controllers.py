# -*- coding: utf-8 -*-
from odoo import http

# class HrBirthdays(http.Controller):
#     @http.route('/hr_birthdays/hr_birthdays/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_birthdays/hr_birthdays/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_birthdays.listing', {
#             'root': '/hr_birthdays/hr_birthdays',
#             'objects': http.request.env['hr_birthdays.hr_birthdays'].search([]),
#         })

#     @http.route('/hr_birthdays/hr_birthdays/objects/<model("hr_birthdays.hr_birthdays"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_birthdays.object', {
#             'object': obj
#         })